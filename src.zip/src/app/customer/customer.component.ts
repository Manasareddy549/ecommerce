import { Component, OnInit } from '@angular/core';

import { BookService } from '../book.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  books:any;
  check:boolean = false;
  message: string;
  check_book_id=false;
  check_book_id1=false;
  check_book_id2=false;
    constructor(private book_service:BookService, private router:Router) { }
  
    ngOnInit(): void {
      this.displayBooks();
    }
    displayBooks():void{
  
    this.book_service.displayBooks().subscribe((data)=>
    {this.books=data,
    console.log(data)},
    (error)=>{
      console.log(error);
    });
    }
  deleteBook(book_id:number){
    this.book_service.deleteBook(book_id).subscribe((data)=>this.books=data);
    this.check = true;
    this.router.navigate[('/app-listbooks')];
  }
  
  book_info(book_id:number){
  this.check_book_id=true;
  }
  book_info1(book_id:number){
    this.check_book_id1=true;
  }
  book_info2(book_id:number){
    this.check_book_id2=true;
  }
  }