import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class AddBook{

  book_id:number;
  category_Id:number;
  category_Name:string;
  title:string;
  author:string;
  description:string;
  isbn:number;
  price:number;
  published_Date:Date;
//bookicon:ImageData;
  constructor(book_id:number,category_Id:number,category_Name:string,title:string, author:string, description:string, isbn:number,price:number,published_Date:Date   ){
    //bookicon:ImageData
 
          this.book_id=book_id;
          this.category_Id=category_Id;
          this.category_Name=category_Name;
          this.title=title;
          this.author=author;
          this.description=description;
          this.isbn=isbn;
          this.price=price;
          this.published_Date=published_Date;
         //this.bookicon=bookicon
      }
}
export class Category{
  category_Id:number;
  category_Name:string;
  constructor(category_Id:number,category_Name:string){
    this.category_Id=category_Id;
    this.category_Name=category_Name;
  }
}
@Injectable({
  providedIn: 'root'
})
export class BookService {
  constructor(private http:HttpClient) { }

  public addBook(book){
    return this.http.post("http://localhost:5677/addbook",book,{responseType:'text'});
  }
  public displayBooks() {
    return this.http.get("http://localhost:5677/displaybooks",{responseType:'json'});
  }
  public deleteBook(id:number){
    return this.http.delete("http://localhost:5677/delete_book/"+id,{responseType:'json'});
  }

  public updateBook(book:any){
    return this.http.put("http://localhost:5677/update_book",book,{responseType:'text'});
  }
  public addCategory(category){
    return this.http.post("http://localhost:5677/add_category",category,{responseType:'text'});
  }
  public displayCategories(){
    return this.http.get("http://localhost:5677/displaycategories",{responseType:'json'});
  }
  public deleteCategory(id:number){
    return this.http.delete("http://localhost:5677/delete_category/"+id,{responseType:'text'});
  }
  public updateCategory(category:any){
    return this.http.put("http://localhost:5677/update_category",category,{responseType:'text'});
  }
}