import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { BookService } from './book.service';
import { FormsModule } from '@angular/forms';
import { AddbookComponent } from './addbook/addbook.component';
import { ListbooksComponent } from './listbooks/listbooks.component';
import { UpdatebookComponent } from './updatebook/updatebook.component';
import { CustomerComponent } from './customer/customer.component';
import { CreatecategoryComponent } from './createcategory/createcategory.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UpdateCategoryComponent } from './update-category/update-category.component';
import { ListOfAllCategoryComponent } from './list-of-all-category/list-of-all-category.component';
@NgModule({
  declarations: [
    AppComponent,
    AddbookComponent,
    ListbooksComponent,
    UpdatebookComponent,
    CustomerComponent,
    CreatecategoryComponent,
    FooterComponent,
    HeaderComponent,
    UpdateCategoryComponent,
    ListOfAllCategoryComponent,
  ],
  imports: [

    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [HttpClientModule,BookService],
  bootstrap: [AppComponent]
  
})
export class AppModule { }


