import { Component, OnInit } from '@angular/core';
import { AddBook, BookService } from '../book.service';

@Component({
  selector: 'app-updatebook',
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdatebookComponent implements OnInit {

  book:AddBook= new AddBook(0,0,"asa","abc","xxx","xyz",0,0,new Date());
  book1:AddBook=new AddBook(0,0,"","","","",0,0,new Date())
  message:string;
  check:boolean=false;
  allbook:any;
  click:boolean=false;
  constructor(private book_service:BookService) { }

  ngOnInit(): void {
    this.book_service.displayBooks().subscribe((data)=>this.allbook=data);
  }

  updateBook(bookData:AddBook){
    this.book1 = bookData;
    this.click = true;
  }
  clickMe(){
    this.click = true;
  }
  updateDetails(){
    this.book_service. updateBook(this.book1).subscribe((data)=>this.message=data);
    this.check=true;
  }
}
