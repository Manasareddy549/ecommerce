import { Component, OnInit } from '@angular/core';
import { BookService, AddBook } from '../book.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-listbooks',
  templateUrl: './listbooks.component.html',
  styleUrls: ['./listbooks.component.css']
})
export class ListbooksComponent implements OnInit {
books:any;
check:boolean = false;
message: string;
imageName: any;
check_book_id=false;
check_book_id1=false;
check_book_id2=false;

book:AddBook= new AddBook(0,0,"asa","abc","xxx","xyz",0,0,new Date());
book1:AddBook=new AddBook(0,0,"","","","",0,0,new Date())
message1:string;
check1:boolean=false;
allbook:any;
click:boolean=false;
  constructor(private book_service:BookService, private router:Router,private http:HttpClient) { }

  ngOnInit(): void {
    this.displayBooks();
    this.book_service.displayBooks().subscribe((data)=>this.allbook=data);
  
  }
  updateBook(bookData:AddBook){
    this.book1 = bookData;
    this.click = true;
  }
  clickMe(){
    this.click = true;
  }
  updateDetails(){
    this.book_service. updateBook(this.book1).subscribe((data)=>this.message1=data);
    this.check1=true;
    this.router.navigate(['/app-updatebook']);
  }
  displayBooks():void{

  this.book_service.displayBooks().subscribe((data)=>
  {this.books=data,
  console.log(data)},
  (error)=>{
    console.log(error);
  });
  }
deleteBook(book_id:number){
  this.book_service.deleteBook(book_id).subscribe((data)=>this.books=data);
  this.check = true;
  this.router.navigate(['/app-listbooks']);
}
delete(book_id:number){
  var retval=confirm("Are you sure want to delete the Book with ID:"+book_id+"?");
if(retval==true){
  this.book_service.deleteBook(book_id).subscribe(
    (result)=>{
      if(result!=null){
        this.books=this.books.filter(books=>books.book_id!=book_id);
        this.router.navigate(['/app-listbooks']);
      }
    },
    (err)=>{
      this.message=err.message;
    }
  );
}
}

book_info(book_id:number){
this.check_book_id=true;
}
book_info1(book_id:number){
  this.check_book_id1=true;
}
book_info2(book_id:number){
  this.check_book_id2=true;
}
}