import { Component, OnInit } from '@angular/core';
import { Category, BookService } from '../book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-of-all-category',
  templateUrl: './list-of-all-category.component.html',
  styleUrls: ['./list-of-all-category.component.css']
})
export class ListOfAllCategoryComponent implements OnInit {
  category:Category= new Category(0,"abc");
  category1:Category= new Category(0,"");
  message1:string;
  check1:boolean=false;
  click:boolean=false;
  allcategory: any;
  categories: Object;
  check: boolean;
  message: any;
  constructor(private book_service:BookService, private router:Router) { }
  ngOnInit(): void {
    this.displayCategories();
    this.book_service.displayCategories().subscribe((data)=>this.allcategory=data);

  }
  displayCategories():void {
    this.book_service.displayCategories().subscribe((data)=>
    {
      this.categories=data;
      console.log(data)},
      (error)=>{
        console.log(error);
      });
    }
  deleteCategory(category_Id:number){
    this.book_service.deleteCategory(category_Id).subscribe((data)=>this.categories=data);
    this.check = true;
    this.router.navigate(['/app-list-of-all-category']);
  }
  
  updateCategory(categoryData:Category){
    this.category1 = categoryData;
    this.click = true;
  }
  clickMe(){
    this.click = true;
  }
  updateDetails(){
    this.book_service. updateBook(this.category1).subscribe((data)=>this.message1=data);
    this.check1=true;
    this.router.navigate(['/app-update-category']);
  }
  delete(category_Id:number){
    var retval=confirm("Are you sure want to delete the Category with ID:"+category_Id+"?");
  if(retval==true){
    this.book_service.deleteCategory(category_Id).subscribe(
      (result)=>{
        if(result!=null){
          this.categories=this.categories.filter(categories=>categories.category_Id!=category_Id);
          this.router.navigate(['/app-listcategories']);
        }
      },
      (error)=>{
        this.message=error.message;
      }
    );
  }
  }
}