import { Component, OnInit } from '@angular/core';
import { Category, BookService } from '../book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {
  category:Category= new Category(0,"abc");
  category1:Category= new Category(0,"");
  message1:string;
  check1:boolean=false;
  click:boolean=false;
  allcategory: any;
  categories: Object;
  check: boolean;
  message: any;
  constructor(private book_service:BookService, private router:Router) { }
  ngOnInit(): void {
    this.book_service.displayCategories().subscribe((data)=>this.allcategory=data);

  }
  
  updateCategory(categoryData:Category){
    this.category1 = categoryData;
    this.click = true;
  }
  clickMe(){
    this.click = true;
  }
  updateDetails(){
    this.book_service. updateBook(this.category1).subscribe((data)=>this.message1=data);
    this.check1=true;
    this.router.navigate[('/app-update-category')];
  }
  
}
