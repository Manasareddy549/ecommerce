import { Component, OnInit } from '@angular/core';
import { BookService, AddBook } from '../book.service';
import { HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})

export class AddbookComponent implements OnInit {
book_obj:AddBook=new AddBook(0,0,"","","","",0,0,new Date());
add_message:string;

check:boolean = true;
check1:boolean = false;

selectedFile: File;
retrievedImage: any;
base64Data: any;
retrieveResonse: any;
message: string;
imageName: any;
  selectedCategory:string='';


 public constructor(private book_service:BookService, private http:HttpClient) {}

  ngOnInit(): void {
  }
  selectChangeHandler(event:any){
    this.selectedCategory=event.target.value;
  }
  url="./assets/DanBrown.jpg";
  onselectFile(e){
    if(e.target.files){
      var reader=new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload=(event:any)=>{
        this.url=event.target.result;
      }
    }
  }
 
add_book(){ 
  if(!isNaN(this.book_obj.book_id))
  {
    this.book_service.addBook(this.book_obj).subscribe((data)=>this.add_message=data);
    this.check=true;
    this.check1=true;
  }
}
/*
//Gets called when the user selects an image
public onFileChanged(event) {
  //Select File
  this.selectedFile = event.target.files[0];
}
//Gets called when the user clicks on submit to upload the image
onUpload() {
  console.log(this.selectedFile);
  
  //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
  const uploadImageData = new FormData();
  uploadImageData.append('imageFile', this.selectedFile, this.selectedFile.name);

  //Make a call to the Spring Boot Application to save the image
  this.http.post('http://localhost:1212/image/upload', uploadImageData, { observe: 'response' })
    .subscribe((response) => {
      if (response.status == 200) {
        this.message = 'Image uploaded successfully';
      } else {
        this.message = 'Image not uploaded successfully';
      }
    }
    );
}
*/

}
