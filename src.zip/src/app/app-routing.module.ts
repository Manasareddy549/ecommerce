import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddbookComponent } from './addbook/addbook.component';
import { ListbooksComponent } from './listbooks/listbooks.component';
import { UpdatebookComponent } from './updatebook/updatebook.component';
import { CustomerComponent } from './customer/customer.component';
import { CreatecategoryComponent } from './createcategory/createcategory.component';
import { ListOfAllCategoryComponent } from './list-of-all-category/list-of-all-category.component';
import { UpdateCategoryComponent } from './update-category/update-category.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes = [
  {path:'Add_Book',component:AddbookComponent},
  {path:'app-listbooks',component: ListbooksComponent},
  {path:'app-updatebook',component:UpdatebookComponent},
  {path:'app-customer',component:CustomerComponent},
  {path:'app-createcategory',component:CreatecategoryComponent},
  {path:'app-list-of-all-category',component:ListOfAllCategoryComponent},
  {path:'app-update-category',component:UpdateCategoryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

