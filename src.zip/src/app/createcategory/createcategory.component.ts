import { Component, OnInit } from '@angular/core';
import { Category, BookService } from '../book.service';

@Component({
  selector: 'app-createcategory',
  templateUrl: './createcategory.component.html',
  styleUrls: ['./createcategory.component.css']
})
export class CreatecategoryComponent implements OnInit {

  cat_obj:Category=new Category(0,"");
  add_message:string;
  
  check:boolean = true;
  check1:boolean = false;

   public constructor(private book_service:BookService) {}
  
    ngOnInit(): void {
    }
    
  add_category(){ 
    if(!isNaN(this.cat_obj.category_Id))
    {
      this.book_service.addCategory(this.cat_obj).subscribe((data)=>this.add_message=data);
      this.check=true;
      this.check1=true;
    }
  }
}